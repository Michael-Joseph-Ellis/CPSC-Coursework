#include "function.c"

int main() {
    printName();
    return 0;
}