#include <stdio.h>

void printName() {
    printf("Hello, world! My name is Michael Ellis.");
}